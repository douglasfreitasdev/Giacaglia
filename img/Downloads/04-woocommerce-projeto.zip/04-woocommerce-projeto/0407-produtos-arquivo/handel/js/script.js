const slide = new Slide('.slide', '.slide-wrapper');
slide.init();